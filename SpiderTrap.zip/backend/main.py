from __future__ import annotations

from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field, field_validator

from backend.services.honeypot import honeypots
from backend.services.network import ALLOWED_PORTS, audit_local_ports, get_local_ip, run_connectivity_check

ROOT = Path(__file__).resolve().parents[1]
FRONTEND = ROOT / "frontend"
ALLOWED_PORT_SET = set(ALLOWED_PORTS)

app = FastAPI(
    title="SpiderTrap",
    description="Console web de laboratório para diagnóstico e observação local de rede.",
    version="1.0.0",
)


class PortSelection(BaseModel):
    ports: list[int] = Field(min_length=1, max_length=3)

    @field_validator("ports")
    @classmethod
    def allow_only_lab_ports(cls, ports: list[int]) -> list[int]:
        if len(ports) != len(set(ports)):
            raise ValueError("Remova portas duplicadas.")
        invalid = sorted(set(ports) - ALLOWED_PORT_SET)
        if invalid:
            raise ValueError(f"Portas fora da lista permitida: {invalid}.")
        return ports


class ListenerStart(PortSelection):
    authorization_confirmed: bool = False

    @field_validator("authorization_confirmed")
    @classmethod
    def require_explicit_authorization(cls, confirmed: bool) -> bool:
        if not confirmed:
            raise ValueError("Confirme a autorização e o aviso de segurança antes de iniciar listeners.")
        return confirmed


@app.get("/api/health")
def health() -> dict[str, str]:
    return {"status": "ok", "service": "SpiderTrap"}


@app.get("/api/status")
def status() -> dict[str, Any]:
    return {
        "local_ip": get_local_ip(),
        "ping_target": "8.8.8.8",
        "audit_target": "127.0.0.1",
        "environment": "GitHub Codespaces" if __import__("os").environ.get("CODESPACES") else "Python local",
    }


@app.post("/api/network/diagnostic")
def network_diagnostic() -> dict[str, Any]:
    return run_connectivity_check()


@app.get("/api/honeypot")
def honeypot_state() -> dict[str, Any]:
    return honeypots.snapshot()


@app.post("/api/honeypot/start")
def start_honeypot(request: ListenerStart) -> dict[str, Any]:
    return honeypots.start(request.ports)


@app.post("/api/honeypot/stop")
def stop_honeypot(request: PortSelection) -> dict[str, Any]:
    return honeypots.stop(request.ports)


@app.delete("/api/honeypot/events")
def clear_honeypot_events() -> dict[str, int]:
    return {"cleared": honeypots.clear_events()}


@app.post("/api/audit")
def local_audit(request: PortSelection) -> dict[str, Any]:
    return {
        "target": "127.0.0.1",
        "results": audit_local_ports(request.ports),
    }


@app.get("/manus-routes.json", include_in_schema=False)
def route_manifest() -> FileResponse:
    return FileResponse(FRONTEND / "manus-routes.json", media_type="application/json")


@app.get("/", include_in_schema=False)
def home() -> FileResponse:
    return FileResponse(FRONTEND / "index.html", media_type="text/html")


app.mount("/assets", StaticFiles(directory=FRONTEND / "assets"), name="assets")
