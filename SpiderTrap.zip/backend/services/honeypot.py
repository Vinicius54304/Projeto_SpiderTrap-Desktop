from __future__ import annotations

import socket
import threading
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

from backend.services.network import ALLOWED_PORTS

BIND_HOST = "0.0.0.0"
MAX_EVENTS = 500


@dataclass
class Listener:
    port: int
    service: str
    state: str = "starting"
    error: str | None = None
    stop_event: threading.Event = field(default_factory=threading.Event)
    sock: socket.socket | None = None
    thread: threading.Thread | None = None


class HoneypotManager:
    """Small, in-memory listener manager for explicitly authorized lab use."""

    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._listeners: dict[int, Listener] = {}
        self._events: deque[dict[str, Any]] = deque(maxlen=MAX_EVENTS)

    def snapshot(self) -> dict[str, Any]:
        with self._lock:
            listeners = []
            for port, service in ALLOWED_PORTS.items():
                current = self._listeners.get(port)
                listeners.append(
                    {
                        "port": port,
                        "service": service,
                        "bind": BIND_HOST,
                        "state": current.state if current else "stopped",
                        "error": current.error if current else None,
                    }
                )
            return {"listeners": listeners, "events": list(self._events)}

    def start(self, ports: list[int]) -> dict[str, Any]:
        started: list[int] = []
        with self._lock:
            for port in ports:
                current = self._listeners.get(port)
                if current and current.state in {"starting", "listening"}:
                    continue
                listener = Listener(port=port, service=ALLOWED_PORTS[port])
                self._listeners[port] = listener
                listener.thread = threading.Thread(
                    target=self._serve,
                    args=(listener,),
                    name=f"honeypot-{port}",
                    daemon=True,
                )
                listener.thread.start()
                started.append(port)
        return {"started": started, **self.snapshot()}

    def stop(self, ports: list[int]) -> dict[str, Any]:
        stopped: list[int] = []
        with self._lock:
            for port in ports:
                listener = self._listeners.get(port)
                if not listener or listener.state in {"stopped", "error"}:
                    continue
                listener.stop_event.set()
                if listener.sock:
                    try:
                        listener.sock.close()
                    except OSError:
                        pass
                stopped.append(port)
        return {"stopping": stopped, **self.snapshot()}

    def clear_events(self) -> int:
        with self._lock:
            count = len(self._events)
            self._events.clear()
            return count

    def _serve(self, listener: Listener) -> None:
        server: socket.socket | None = None
        try:
            server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            server.bind((BIND_HOST, listener.port))
            server.listen(16)
            server.settimeout(0.75)
            with self._lock:
                listener.sock = server
                if listener.stop_event.is_set():
                    return
                listener.state = "listening"
                listener.error = None

            while not listener.stop_event.is_set():
                try:
                    connection, remote = server.accept()
                except socket.timeout:
                    continue
                except OSError:
                    if listener.stop_event.is_set():
                        break
                    raise

                event = {
                    "time": datetime.now().astimezone().isoformat(timespec="seconds"),
                    "port": listener.port,
                    "service": listener.service,
                    "remote_ip": remote[0],
                    "remote_port": remote[1],
                }
                with self._lock:
                    self._events.appendleft(event)
                try:
                    connection.sendall(b"SpiderTrap lab listener. Connection recorded.\n")
                except OSError:
                    pass
                finally:
                    connection.close()
        except OSError as exc:
            with self._lock:
                if not listener.stop_event.is_set():
                    listener.state = "error"
                    if exc.errno in {1, 13}:
                        listener.error = "Permissão negada: esta porta pode exigir privilégios elevados."
                    elif exc.errno in {98, 10048}:
                        listener.error = "A porta já está em uso por outro processo."
                    else:
                        listener.error = str(exc)
        finally:
            if server:
                try:
                    server.close()
                except OSError:
                    pass
            with self._lock:
                listener.sock = None
                if listener.state != "error":
                    listener.state = "stopped"


honeypots = HoneypotManager()
