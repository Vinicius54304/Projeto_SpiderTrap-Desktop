from __future__ import annotations

import platform
import shutil
import socket
import subprocess
from typing import Any

PING_TARGET = "8.8.8.8"
AUDIT_TARGET = "127.0.0.1"
ALLOWED_PORTS = {21: "FTP", 22: "SSH", 3389: "RDP"}


def get_local_ip() -> str:
    """Detect the preferred local address without sending application data."""
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.connect((PING_TARGET, 80))
        return sock.getsockname()[0]
    except OSError:
        return "127.0.0.1"
    finally:
        sock.close()


def run_connectivity_check() -> dict[str, Any]:
    """Run four ICMP requests to the fixed diagnostic target."""
    ping = shutil.which("ping")
    if not ping:
        return {
            "ok": False,
            "target": PING_TARGET,
            "local_ip": get_local_ip(),
            "summary": "O comando ping não está disponível neste ambiente.",
            "output": "",
        }

    is_windows = platform.system().lower() == "windows"
    command = [ping, "-n" if is_windows else "-c", "4", PING_TARGET]
    if not is_windows:
        command = [ping, "-W", "2", *command[1:]]

    try:
        result = subprocess.run(
            command,
            capture_output=True,
            text=True,
            errors="replace",
            timeout=14,
            check=False,
        )
        output = (result.stdout or result.stderr).strip()
        return {
            "ok": result.returncode == 0,
            "target": PING_TARGET,
            "local_ip": get_local_ip(),
            "summary": "Destino respondeu." if result.returncode == 0 else "Sem resposta do destino.",
            "output": output,
        }
    except subprocess.TimeoutExpired as exc:
        output = exc.stdout or ""
        if isinstance(output, bytes):
            output = output.decode(errors="replace")
        return {
            "ok": False,
            "target": PING_TARGET,
            "local_ip": get_local_ip(),
            "summary": "O teste excedeu o limite de 14 segundos.",
            "output": output,
        }
    except OSError as exc:
        return {
            "ok": False,
            "target": PING_TARGET,
            "local_ip": get_local_ip(),
            "summary": "Não foi possível iniciar o teste de conectividade.",
            "output": str(exc),
        }


def audit_local_ports(ports: list[int]) -> list[dict[str, Any]]:
    """Check only the allowlisted ports on loopback; no host can be supplied."""
    results: list[dict[str, Any]] = []
    for port in ports:
        service = ALLOWED_PORTS[port]
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(0.55)
        try:
            code = sock.connect_ex((AUDIT_TARGET, port))
            results.append(
                {
                    "port": port,
                    "service": service,
                    "target": AUDIT_TARGET,
                    "open": code == 0,
                    "status": "open" if code == 0 else "closed",
                }
            )
        except OSError as exc:
            results.append(
                {
                    "port": port,
                    "service": service,
                    "target": AUDIT_TARGET,
                    "open": False,
                    "status": "error",
                    "error": str(exc),
                }
            )
        finally:
            sock.close()
    return results
