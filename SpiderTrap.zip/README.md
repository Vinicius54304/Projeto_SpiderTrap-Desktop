# SpiderTrap

Console web para diagnóstico de conectividade, monitoramento honeypot e auditoria **somente do próprio ambiente**. A interface roda no navegador; toda operação de rede é executada por um backend Python FastAPI.

## Executar no GitHub Codespaces

Abra o terminal do Codespace e rode:

```bash
python -m pip install -r requirements.txt
python -m uvicorn backend.main:app --host 0.0.0.0 --port 3000 --reload
```

Na primeira criação do Codespace, a configuração em `.devcontainer/devcontainer.json` instala `iputils-ping` e as dependências Python. Se você já tinha um Codespace aberto antes de copiar estes arquivos, rode `sudo apt-get update && sudo apt-get install -y iputils-ping` e `python -m pip install -r requirements.txt` uma vez, ou escolha **Codespaces: Rebuild Container** na Paleta de Comandos. Quando o Codespace encaminhar a porta **3000**, abra a aba **Ports** e clique em **Open in Browser**. A interface e o backend são servidos pela mesma aplicação; não é necessário iniciar React, PySide6, X11, xvfb, VNC ou um segundo servidor.

Também funciona em Linux, macOS ou Windows com Python 3.10+. O diagnóstico ICMP requer o comando de sistema `ping` (no Debian/Ubuntu, instale com `sudo apt-get update && sudo apt-get install -y iputils-ping`). No Windows use `py -m pip install -r requirements.txt` e `py -m uvicorn backend.main:app --host 0.0.0.0 --port 3000 --reload`.

## O que funciona

- **Visão geral:** detecta o IP local e executa quatro solicitações `ping` a `8.8.8.8` sob demanda. Se `ping` não estiver disponível ou o Codespace bloquear ICMP, a interface mostra o motivo/resultado em vez de simular sucesso.
- **Honeypot:** tenta iniciar ou interromper listeners TCP em `21` (FTP), `22` (SSH) e `3389` (RDP), individualmente. Cada listener exibe seu estado ou o erro retornado pelo sistema. Uma confirmação explícita no navegador e no endpoint é exigida antes de iniciar.
- **Eventos:** registra em memória a data/hora, porta de destino e IP/porta remotos das conexões recebidas. Os registros somem ao reiniciar o processo; até 500 eventos são mantidos.
- **Auditoria local:** consulta apenas as portas selecionadas da lista permitida (`21`, `22`, `3389`) no endereço fixo `127.0.0.1`. A API não aceita um host arbitrário e rejeita portas fora da lista.

## Limitações e segurança

Os listeners tentam fazer `bind` em `0.0.0.0`, ou seja, em todas as interfaces do ambiente onde o backend está rodando. O aviso no app é intencional: uma porta encaminhada no Codespace pode ficar acessível a outras pessoas. Use somente em uma máquina/rede que você administra ou tem autorização explícita para monitorar; revise a visibilidade das portas encaminhadas antes de iniciar listeners.

No Codespaces, a porta `21` normalmente exige privilégios elevados e `22` pode já estar em uso. O Codespace também pode bloquear ou não encaminhar essas portas. Nesses casos o app apresenta **Falha**, não finge que o listener está funcionando. Não rode o servidor como root apenas para contornar esses erros; prefira um ambiente de laboratório controlado. Portas encaminhadas são gerenciadas na aba **Ports** do Codespace.

O ping depende do comando de sistema `ping` e de acesso ICMP de saída. A verificação de portas não escaneia hosts externos, sub-redes ou portas além das três descritas. Não há autenticação: execute apenas em um Codespace privado/de confiança e não compartilhe o encaminhamento do app ou de portas de honeypot sem compreender as consequências.

## Endpoints do backend

- `GET /api/health` e `GET /api/status`
- `POST /api/network/diagnostic`
- `GET /api/honeypot`, `POST /api/honeypot/start`, `POST /api/honeypot/stop`, `DELETE /api/honeypot/events`
- `POST /api/audit`
- Documentação interativa do FastAPI: `/docs`

## Estrutura

```text
backend/
  main.py                 # rotas FastAPI e validação dos pedidos
  services/network.py     # IP local, ping e auditoria loopback allowlisted
  services/honeypot.py    # listeners e eventos em memória
frontend/
  index.html              # interface em português
  assets/app.css          # identidade visual responsiva
  assets/app.js           # navegação e integração com a API
  assets/spider-mark.webp # símbolo da marca, incluído no repositório
.devcontainer/            # configuração de Codespaces
docs/design-notes.md      # referências de design e decisões de interface
```
