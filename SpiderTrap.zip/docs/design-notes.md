# Notas de design

O redesenho preserva o HTML/CSS/JavaScript e o backend FastAPI já existentes. Não copia uma tela pronta nem adiciona dependências de UI. A ideia é que o SpiderTrap pareça uma ferramenta pequena e feita para este uso: nome visível, ações explicadas em português simples, dados alinhados e cor reservada para indicar ação ou estado.

Da Taste Skill, foi aproveitada a orientação específica para telas de app: separar as tarefas reais da tela, escrever conteúdo útil para os estados vazio e carregando, evitar decoração sem função, não comprimir o layout desktop no celular e eliminar os sinais comuns de interface genérica — numeração artificial, micro-rótulos em excesso, monospace em todo lugar, cartões decorativos, gradientes e sombras pesadas. As tabelas e linhas discretas continuam onde ajudam a ler estado e portas.

Da Transitions.dev, foram aplicados movimentos breves na troca de página, abertura do diálogo e toast. O movimento usa `opacity` e `transform`, sem animar layout em cada quadro. As regras `prefers-reduced-motion` mantêm a interface utilizável para quem reduz animações. Nenhum pacote externo de motion foi necessário.

A marca gráfica é uma aranha simples gerada para o produto, armazenada dentro do próprio repositório para que também funcione fora da prévia Manus.

## Referências consultadas

- Taste Skill, documentos e orientações de app screens: https://www.tasteskill.dev/docs
- Taste Skill, descrição e princípios gerais: https://www.tasteskill.dev/
- Transitions.dev, catálogo de transições: https://transitions.dev/library.html
- Transitions.dev, documentação da skill: https://transitions.dev/skill.html
