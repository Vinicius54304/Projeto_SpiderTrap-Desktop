import unittest

from pydantic import ValidationError

from backend.main import ListenerStart, PortSelection
from backend.services.network import ALLOWED_PORTS, AUDIT_TARGET


class RequestContractTests(unittest.TestCase):
    def test_audit_only_accepts_the_three_lab_ports(self):
        valid = PortSelection(ports=[21, 22, 3389])
        self.assertEqual(valid.ports, [21, 22, 3389])
        self.assertEqual(AUDIT_TARGET, "127.0.0.1")
        self.assertEqual(set(ALLOWED_PORTS), {21, 22, 3389})

    def test_audit_rejects_other_ports_and_empty_selection(self):
        with self.assertRaises(ValidationError):
            PortSelection(ports=[80])
        with self.assertRaises(ValidationError):
            PortSelection(ports=[])

    def test_start_requires_authorization_confirmation(self):
        with self.assertRaises(ValidationError):
            ListenerStart(ports=[3389], authorization_confirmed=False)
        valid = ListenerStart(ports=[3389], authorization_confirmed=True)
        self.assertTrue(valid.authorization_confirmed)

    def test_duplicate_ports_are_rejected(self):
        with self.assertRaises(ValidationError):
            PortSelection(ports=[21, 21])


if __name__ == "__main__":
    unittest.main()
