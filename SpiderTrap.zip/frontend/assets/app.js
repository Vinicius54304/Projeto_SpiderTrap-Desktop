const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const allowedPorts = [21, 22, 3389];
const serviceNames = { 21: 'FTP', 22: 'SSH', 3389: 'RDP' };
let lastSnapshot = { listeners: [], events: [] };
let pendingPorts = [];
let toastTimer;

async function api(path, options = {}) {
  const response = await fetch(path, {
    ...options,
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
  });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) {
    const detail = Array.isArray(body.detail)
      ? body.detail.map((item) => item.msg).join(' ')
      : body.detail || `Falha na solicitação (${response.status}).`;
    throw new Error(detail);
  }
  return body;
}

function notify(message) {
  const toast = $('#toast');
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('show'), 3600);
}

function setBackendState(online, label = '') {
  $('#backendDot').className = `status-dot ${online ? 'good' : 'bad'}`;
  $('#topStatusDot').className = `status-dot ${online ? 'good' : 'bad'}`;
  $('#backendLabel').textContent = online ? 'Servidor conectado' : 'Servidor indisponível';
  $('#topStatusText').textContent = online ? 'Conectado' : 'Desconectado';
  if (label) $('#environmentLabel').textContent = label;
}

function formatTime(iso) {
  if (!iso) return '—';
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return iso;
  return new Intl.DateTimeFormat('pt-BR', { hour: '2-digit', minute: '2-digit', second: '2-digit' }).format(date);
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (character) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  })[character]);
}

function stateText(state) {
  return ({ listening: 'Escutando', starting: 'Iniciando', stopped: 'Parado', error: 'Falha' })[state] || state;
}

function renderListeners(listeners) {
  const rows = [...listeners].sort((a, b) => a.port - b.port);
  $('#overviewListeners').innerHTML = rows.map((listener) => {
    const status = escapeHtml(listener.state);
    const extra = listener.error ? ` title="${escapeHtml(listener.error)}"` : '';
    return `<tr>
      <td><span class="service-cell"><span class="service-mark">${escapeHtml(listener.service.slice(0, 2))}</span>${escapeHtml(listener.service)}</span></td>
      <td class="port-mono">${listener.port}</td>
      <td${extra}><span class="status-label ${status}">${escapeHtml(stateText(listener.state))}</span></td>
      <td><button class="row-link" type="button" data-page="sensors">Configurar →</button></td>
    </tr>`;
  }).join('') || '<tr><td colspan="4" class="empty-cell">Nenhum honeypot configurado.</td></tr>';
  $$('#overviewListeners [data-page]').forEach((button) => button.addEventListener('click', () => navigate('sensors')));

  const active = rows.filter((row) => row.state === 'listening').length;
  $('#activeCount').textContent = String(active);
  $('#sensorList').innerHTML = rows.map((listener) => {
    const isActive = listener.state === 'listening';
    const isStarting = listener.state === 'starting';
    const checked = pendingPorts.includes(listener.port) ? 'checked' : '';
    const status = escapeHtml(listener.state);
    const error = listener.error ? `<div class="sensor-error">${escapeHtml(listener.error)}</div>` : '';
    return `<div class="sensor-row" data-port="${listener.port}">
      <label class="sensor-check" aria-label="Selecionar porta ${listener.port}"><input type="checkbox" class="sensor-port-check" value="${listener.port}" ${checked}><span class="checkbox-look"></span></label>
      <div class="sensor-service"><strong>${escapeHtml(listener.service)}</strong><small>${listener.port === 3389 ? 'Remote Desktop Protocol' : listener.port === 22 ? 'Secure Shell' : 'File Transfer Protocol'}</small></div>
      <span class="sensor-port">:${listener.port}</span>
      <span class="sensor-bind"><strong>Endereço</strong>${escapeHtml(listener.bind)}</span>
      <span class="status-label ${status}"${listener.error ? ` title="${escapeHtml(listener.error)}"` : ''}>${escapeHtml(stateText(listener.state))}</span>
      <button class="button ${isActive ? 'stop' : 'button-dark'}" type="button" data-toggle-port="${listener.port}" ${isStarting ? 'disabled' : ''}>${isStarting ? 'Iniciando…' : isActive ? 'Interromper' : 'Iniciar'}</button>
      ${error}
    </div>`;
  }).join('');

  $$('#sensorList .sensor-port-check').forEach((checkbox) => {
    checkbox.addEventListener('change', () => {
      const port = Number(checkbox.value);
      pendingPorts = checkbox.checked ? [...new Set([...pendingPorts, port])] : pendingPorts.filter((item) => item !== port);
    });
  });
  $$('#sensorList [data-toggle-port]').forEach((button) => {
    button.addEventListener('click', () => {
      const port = Number(button.dataset.togglePort);
      const listener = rows.find((item) => item.port === port);
      if (listener?.state === 'listening') stopListeners([port]);
      else askToStart([port]);
    });
  });
}

function renderEvents(events) {
  const recent = events.slice(0, 6);
  $('#eventCount').textContent = `${events.length} ${events.length === 1 ? 'evento' : 'eventos'}`;
  $('#sensorEventCount').textContent = `${events.length} ${events.length === 1 ? 'evento' : 'eventos'}`;
  if (!recent.length) {
    $('#overviewEvents').innerHTML = '<div class="empty-state">Nenhuma conexão registrada nesta sessão.</div>';
    $('#sensorEvents').innerHTML = '<tr><td colspan="4" class="empty-cell">Nenhuma conexão registrada nesta sessão.</td></tr>';
    return;
  }
  $('#overviewEvents').innerHTML = recent.map((event) => `<div class="event-item">
    <span class="event-time">${escapeHtml(formatTime(event.time))}</span><span class="event-service">${escapeHtml(event.service)}</span>
    <span class="event-origin">${escapeHtml(event.remote_ip)}:${escapeHtml(event.remote_port)}</span><span class="event-port">→ :${event.port}</span>
  </div>`).join('');
  $('#sensorEvents').innerHTML = events.map((event) => `<tr>
    <td class="port-mono">${escapeHtml(formatTime(event.time))}</td><td>${escapeHtml(event.service)}</td>
    <td class="port-mono">:${event.port}</td><td class="port-mono">${escapeHtml(event.remote_ip)}:${escapeHtml(event.remote_port)}</td>
  </tr>`).join('');
}

async function refreshSnapshot() {
  try {
    const [state, status] = await Promise.all([api('/api/honeypot'), api('/api/status')]);
    lastSnapshot = state;
    renderListeners(state.listeners);
    renderEvents(state.events);
    $('#localIp').textContent = status.local_ip || 'Indisponível';
    $('#environmentLabel').textContent = status.environment || 'Python local';
    setBackendState(true);
  } catch (error) {
    setBackendState(false);
    $('#overviewListeners').innerHTML = '<tr><td colspan="4" class="empty-cell">Não foi possível consultar os honeypots. Verifique se o servidor está em execução.</td></tr>';
  }
}

async function runPing() {
  const button = $('#pingButton');
  const result = $('#pingResult');
  const time = $('#lastPingTime');
  button.disabled = true;
  button.innerHTML = '<span>Testando conectividade…</span><span aria-hidden="true">· · ·</span>';
  result.dataset.state = 'loading';
  result.textContent = 'Quatro solicitações estão em andamento.';
  try {
    const data = await api('/api/network/diagnostic', { method: 'POST', body: '{}' });
    $('#localIp').textContent = data.local_ip || 'Indisponível';
    result.dataset.state = data.ok ? 'ok' : 'error';
    result.textContent = data.summary;
    time.textContent = new Intl.DateTimeFormat('pt-BR', { hour: '2-digit', minute: '2-digit', second: '2-digit' }).format(new Date());
    setBackendState(true);
    if (data.output) console.info('[SpiderTrap] Saída do ping:\n' + data.output);
  } catch (error) {
    result.dataset.state = 'error';
    result.textContent = error.message;
    notify(error.message);
  } finally {
    button.disabled = false;
  button.innerHTML = '<span>Testar conexão</span><span aria-hidden="true">→</span>';
  }
}

function askToStart(ports) {
  pendingPorts = ports.filter((port) => allowedPorts.includes(port));
  if (!pendingPorts.length) {
    notify('Selecione pelo menos uma porta permitida.');
    return;
  }
  const names = pendingPorts.map((port) => `${serviceNames[port]} :${port}`).join(', ');
  $('#confirmDescription').textContent = `O SpiderTrap tentará abrir ${names} em todas as interfaces do ambiente. Se as portas estiverem encaminhadas, outras pessoas podem alcançá-las. Continue apenas se você administra este ambiente ou tem autorização para monitorá-lo.`;
  $('#authorizationCheck').checked = false;
  $('#confirmStartButton').disabled = true;
  $('#confirmStartButton').textContent = `Iniciar ${pendingPorts.length === 1 ? 'listener' : 'listeners'}`;
  $('#confirmDialog').showModal();
}

$('#authorizationCheck').addEventListener('change', (event) => {
  $('#confirmStartButton').disabled = !event.target.checked;
});

$('#confirmForm').addEventListener('submit', async (event) => {
  if (event.submitter?.value !== 'confirm') return;
  event.preventDefault();
  const button = $('#confirmStartButton');
  const ports = [...pendingPorts];
  button.disabled = true;
  button.textContent = 'Iniciando…';
  try {
    await api('/api/honeypot/start', {
      method: 'POST',
      body: JSON.stringify({ ports, authorization_confirmed: $('#authorizationCheck').checked }),
    });
    $('#confirmDialog').close();
    notify(`Solicitação enviada para ${ports.map((port) => `:${port}`).join(', ')}.`);
    await refreshSnapshot();
    setTimeout(refreshSnapshot, 900);
  } catch (error) {
    button.disabled = !$('#authorizationCheck').checked;
    button.textContent = `Iniciar ${ports.length === 1 ? 'listener' : 'listeners'}`;
    notify(error.message);
  }
});

async function stopListeners(ports) {
  try {
    await api('/api/honeypot/stop', { method: 'POST', body: JSON.stringify({ ports }) });
    notify(`Solicitação de parada enviada para ${ports.map((port) => `:${port}`).join(', ')}.`);
    await refreshSnapshot();
    setTimeout(refreshSnapshot, 900);
  } catch (error) {
    notify(error.message);
  }
}

$('#armSelectedButton').addEventListener('click', () => {
  const selected = $$('#sensorList .sensor-port-check:checked').map((checkbox) => Number(checkbox.value));
  askToStart(selected);
});

$('#clearEventsButton').addEventListener('click', async () => {
  try {
    const result = await api('/api/honeypot/events', { method: 'DELETE' });
    notify(`${result.cleared} registro(s) removido(s).`);
    await refreshSnapshot();
  } catch (error) { notify(error.message); }
});

$('#auditButton').addEventListener('click', runAudit);
async function runAudit() {
  const button = $('#auditButton');
  const message = $('#auditMessage');
  const selected = $$('input[name="audit-port"]:checked').map((input) => Number(input.value));
  if (!selected.length) {
    message.textContent = 'Marque pelo menos uma porta.';
    return;
  }
  button.disabled = true;
  button.innerHTML = '<span>Verificando…</span>';
  message.textContent = `Consultando ${selected.length} porta(s) em 127.0.0.1.`;
  $('#auditResults').innerHTML = '<tr><td colspan="4" class="empty-cell">A auditoria está em andamento…</td></tr>';
  try {
    const data = await api('/api/audit', { method: 'POST', body: JSON.stringify({ ports: selected }) });
    $('#auditResults').innerHTML = data.results.map((item) => {
      const state = item.status === 'open' ? 'open' : item.status === 'closed' ? 'closed' : 'error';
      const label = state === 'open' ? 'Aberta' : state === 'closed' ? 'Fechada' : 'Erro';
      return `<tr><td class="port-mono">${item.port}</td><td>${escapeHtml(item.service)}</td><td><span class="result-pill ${state}"${item.error ? ` title="${escapeHtml(item.error)}"` : ''}>${label}</span></td></tr>`;
    }).join('');
    const open = data.results.filter((item) => item.open).length;
    message.textContent = `Concluído: ${data.results.length} portas verificadas; ${open} abertas.`;
  } catch (error) {
    $('#auditResults').innerHTML = `<tr><td colspan="3" class="empty-cell">${escapeHtml(error.message)}</td></tr>`;
    message.textContent = 'A auditoria não foi concluída.';
  } finally {
    button.disabled = false;
    button.innerHTML = 'Verificar portas <span aria-hidden="true">→</span>';
  }
}

function navigate(page) {
  const validPage = ['overview', 'sensors', 'audit'].includes(page) ? page : 'overview';
  $$('.page').forEach((section) => {
    const active = section.id === `page-${validPage}`;
    section.classList.toggle('active', active);
    section.hidden = !active;
  });
  $$('.nav-item').forEach((button) => {
    const active = button.dataset.page === validPage;
    button.classList.toggle('active', active);
    if (active) button.setAttribute('aria-current', 'page');
    else button.removeAttribute('aria-current');
  });
  $('#crumbCurrent').textContent = ({ overview: 'Visão geral', sensors: 'Honeypot', audit: 'Portas locais' })[validPage];
  history.replaceState(null, '', `#${validPage}`);
}

$$('[data-page]').forEach((button) => button.addEventListener('click', () => navigate(button.dataset.page)));

function updateClock() {
  $('#clock').textContent = new Intl.DateTimeFormat('pt-BR', { hour: '2-digit', minute: '2-digit' }).format(new Date());
}

$('#pingButton').addEventListener('click', runPing);
updateClock();
setInterval(updateClock, 30_000);
const initialPage = location.hash.slice(1);
if (initialPage) navigate(initialPage);
refreshSnapshot();
setInterval(refreshSnapshot, 3000);
